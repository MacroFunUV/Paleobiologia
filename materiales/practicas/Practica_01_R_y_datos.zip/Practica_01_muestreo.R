# Paleobiología Esencial · Práctica 1
# Ejecuta los pasos en orden.

# Paso 1
# Comprueba la carpeta de trabajo y que R ve los dos CSV.
getwd()
list.files()

# Los archivos no tienen cabecera. [[1]] extrae la primera columna.
tabla_antigua <- read.csv("genus-europe-750-550.csv", header = FALSE)
tabla_reciente <- read.csv("genus-europe-200-0.csv", header = FALSE)

# Quita espacios sobrantes al principio y al final de cada nombre.
antiguo <- trimws(tabla_antigua[[1]])
reciente <- trimws(tabla_reciente[[1]])

# Muestra los primeros registros y comprueba si hay nombres vacíos.
head(antiguo)
head(reciente)
stopifnot(!anyNA(antiguo), all(nzchar(antiguo)))
stopifnot(!anyNA(reciente), all(nzchar(reciente)))

# Paso 2
# Un recuento de filas y otro de nombres distintos para cada lista.
resumen <- data.frame(
  intervalo = c("750-550 Ma", "200-0 Ma"),
  registros = c(length(antiguo), length(reciente)),
  generos = c(length(unique(antiguo)), length(unique(reciente)))
)
print(resumen)

# Los seis géneros con más registros en la lista antigua.
frecuencias_antigua <- table(antiguo)
frecuencias_reciente <- table(reciente)
head(sort(frecuencias_antigua, decreasing = TRUE))

# Paso 3
set.seed(2026)
n <- 250
submuestra <- sample(antiguo, size = n, replace = FALSE)
length(submuestra)          # 250 registros seleccionados.
length(unique(submuestra))  # Géneros en este sorteo.

# Paso 4
set.seed(2026)
riquezas <- replicate(500, {
  seleccion <- sample(antiguo, size = n, replace = FALSE)
  length(unique(seleccion))
})
mean(riquezas)
range(riquezas)

# Paso 5
# Esta función recibe la tabla de frecuencias y el tamaño de submuestra.
riqueza_esperada <- function(frecuencias, tamano) {
  frecuencia <- as.integer(frecuencias)
  total <- sum(frecuencia)

  # lower.tail = FALSE pide la probabilidad de superar cero.
  presencia <- phyper(0, m = frecuencia, n = total - frecuencia,
                      k = tamano, lower.tail = FALSE)
  sum(presencia)
}

# Comprueba el resultado exacto del ejemplo de cinco registros.
riqueza_esperada(table(c("A", "A", "B", "B", "C")), 2)

# Contrasta el promedio simulado con el resultado exacto.
riqueza_esperada(frecuencias_antigua, 250)
riqueza_esperada(frecuencias_reciente, 250)

# Un tamaño común puede llegar hasta el total de la lista más pequeña.
tamanos <- 0:min(length(antiguo), length(reciente))
curva_antigua <- vapply(tamanos, function(n) {
  riqueza_esperada(frecuencias_antigua, n)
}, numeric(1))
curva_reciente <- vapply(tamanos, function(n) {
  riqueza_esperada(frecuencias_reciente, n)
}, numeric(1))

# plot() abre el gráfico y lines() añade la segunda curva.
plot(tamanos, curva_antigua, type = "l", lwd = 2, col = "#17606b",
     ylim = range(c(curva_antigua, curva_reciente)),
     xlab = "Número de registros", ylab = "Géneros esperados")
lines(tamanos, curva_reciente, lwd = 2, lty = 2, col = "#9a4a26")
legend("topleft", c("750-550 Ma", "200-0 Ma"),
       col = c("#17606b", "#9a4a26"), lty = c(1, 2), lwd = 2, bty = "n")

# Paso 6
porcentajes <- 0:100

curva_relativa <- function(frecuencias) {
  tamanos <- round(sum(frecuencias) * porcentajes / 100)
  esperados <- vapply(tamanos, function(n) {
    riqueza_esperada(frecuencias, n)
  }, numeric(1))
  esperados / length(frecuencias)
}

plot(porcentajes, curva_relativa(frecuencias_antigua), type = "l",
     ylim = c(0, 1), lwd = 2, col = "#17606b",
     xlab = "Registros seleccionados (% de cada lista)",
     ylab = "Fracción esperada de los géneros de la lista")
lines(porcentajes, curva_relativa(frecuencias_reciente),
      lwd = 2, lty = 2, col = "#9a4a26")
legend("bottomright", c("750-550 Ma", "200-0 Ma"),
       col = c("#17606b", "#9a4a26"), lty = c(1, 2), lwd = 2, bty = "n")
